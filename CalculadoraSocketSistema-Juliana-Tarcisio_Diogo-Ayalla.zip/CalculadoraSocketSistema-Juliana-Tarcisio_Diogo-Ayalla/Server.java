import java.util.*;
import java.io.*;
import java.net.*;
import java.rmi.*;

public class Server implements Runnable {

	public Socket connect;

	private static List<Socket> Clientes = new ArrayList<Socket>();

	
	public Server(Socket c) {
		this.connect = c;
	}

	public static void main(String[] args) throws IOException {

		ServerSocket s = new ServerSocket(12345);

		while (true) {
			System.out.println("### Servidor Iniciado!");
			Socket c = s.accept();
			
			System.out.println("Nova Conexao!");
			Clientes.add(c);

			Server op = new Server(c);
			
			Thread t = new Thread(op);

			t.start();
		}
	}
	
	public void run() {

		try {

			while (true) {
				
					DataInputStream inFromClient = new DataInputStream(connect.getInputStream());
					
					int num1 = inFromClient.readInt();
					int num2 = inFromClient.readInt();
					
					int select = inFromClient.readInt();

					if (select == 1) {
						InterServerArit obj = (InterServerArit) Naming.lookup("rmi://localhost/ServerArit");
						
						int result = obj.subtracao(num1, num2);
						
						DataOutputStream saida = new DataOutputStream(connect.getOutputStream());
						
						saida.writeUTF(Integer.toString(result));
					} else

					if (select == 2) {
						InterServerArit obj = (InterServerArit) Naming.lookup("rmi://localhost/ServerArit");
						
						int result = obj.adicao(num1, num2);
						
						DataOutputStream saida = new DataOutputStream(connect.getOutputStream());
						
						saida.writeUTF(Integer.toString(result));
					} else

					if (select == 3) {
						InterServerArit obj = (InterServerArit) Naming.lookup("rmi://localhost/ServerArit");
						
						float result = obj.divisao(num1, num2);
						
						DataOutputStream saida = new DataOutputStream(connect.getOutputStream());
						
						saida.writeUTF(Float.toString(result));
					} else

					if (select == 4) {
						InterServerArit obj = (InterServerArit) Naming.lookup("rmi://localhost/ServerArit");
						
						int result = obj.multiplicacao(num1, num2);
						
						DataOutputStream saida = new DataOutputStream(connect.getOutputStream());
						
						saida.writeUTF(Float.toString(result));
					} else

					if (select == 5) {
						InterServerEsp obj = (InterServerEsp) Naming.lookup("rmi://localhost/ServerEsp");
						
						float result = obj.porcentagem(num1, num2);
						
						DataOutputStream saida = new DataOutputStream(connect.getOutputStream());
						
						saida.writeUTF(Float.toString(result));
					} else

					if (select == 6) {
						InterServerEsp obj = (InterServerEsp) Naming.lookup("rmi://localhost/ServerEsp");
						
						double result = obj.potenciacao(num1, num2);
						
						DataOutputStream saida = new DataOutputStream(connect.getOutputStream());
						
						saida.writeUTF(Double.toString(result));
					} else 					
						if (select == 7) {
						InterServerEsp obj = (InterServerEsp) Naming.lookup("rmi://localhost/ServerEsp");
						
						double result = obj.raizQuadrada(num1);
						
						DataOutputStream saida = new DataOutputStream(connect.getOutputStream());
						
						saida.writeUTF(Double.toString(result));
					}

			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
