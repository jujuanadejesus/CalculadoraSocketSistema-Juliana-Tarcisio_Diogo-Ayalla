# CalculadoraRmiSocketSistema

O objetivo deste projeto é desenvolver um pequeno sistema distribuído de servidores utilizando sockets (Calculadora). 
O projeto será composto de algumas etapas, que serão avaliadas em conjunto.
O sistema/programa a ser implementado pode ser desenvolvido em Java e deve executar no Linux/ Windows. 
Os fontes, executáveis e o texto devem ser disponibilizados no github. 
O sistema será composto de: um webservice rest encaminhará as operações via sockets para servidores especialistas multithread - servidor especialista A que será encarregado de realizar as 4 operações básicas - servidor especialista B que realizará as operações de porcentagem, raiz quadrada e potenciação. Um arquivo de texto, tipo README deve descrever as decisões de projeto, entre ela as relacionadas a protocolo criado, endereçamento, registro, portas, obtenção destas informações, etc. 


- Deve ter 3 componentes (webservice, servidor 1, servidor 2)
- Deve ser multithread
- Deve executar corretamente as operações em cada servidor conforme requisitado
- Deve executar a conexão do webservice com os dois servidores
- Deve tratar as exceções de: operação inválida, divisão por zero
- Deve tratar apenas um operador e dois operandos
  

Equipe: Juliana de Jesus, Tarcísio Ramon, Diogo José e Ayalla Almeida