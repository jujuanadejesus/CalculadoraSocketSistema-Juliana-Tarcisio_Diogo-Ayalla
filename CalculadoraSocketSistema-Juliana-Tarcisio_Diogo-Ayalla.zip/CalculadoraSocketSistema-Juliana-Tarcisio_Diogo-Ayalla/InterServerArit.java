import java.rmi.Remote;
import java.rmi.RemoteException;

public interface InterServerArit extends Remote {
	
	public int subtracao(int a, int b) throws RemoteException;
	
	public int adicao(int a, int b) throws RemoteException;
	
	public float divisao(float x, float y) throws RemoteException;

	public int multiplicacao(int a, int b) throws RemoteException;

}
