import java.rmi.*;
import java.rmi.server.*;

public class ServerAritImpl extends UnicastRemoteObject implements InterServerArit {

    public ServerAritImpl() throws RemoteException {
        super();
    }

    public int subtracao(int a, int b) throws RemoteException {
        return a - b;
    }

    public int adicao(int a, int b) throws RemoteException {
        return a + b;
    }


	public float divisao(float x, float y) throws RemoteException {

        return (x / y);
	}


	public int multiplicacao(int a, int b) throws RemoteException {

        return a * b;
	}
}
