import java.rmi.*;
import java.rmi.registry.LocateRegistry;

public class ServerArit {
    public static void main(String args[]) {

        try {
            LocateRegistry.createRegistry(1099);
            
            ServerAritImpl obj = new ServerAritImpl();
            
            Naming.rebind("ServerArit", obj);
            
            System.out.println("RMI Escravo Aritmetico");
            
        } catch (Exception e) {
            System.out.println("Error" + e.getMessage());
        }
    }
}
